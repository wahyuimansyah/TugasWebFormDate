<?php
include "koneksi.php";
$hari = $_POST['tgl'];
$bulan = $_POST['bln'];
$tahun = $_POST['thn'];

$waktu = $tahun."-".$bulan."-".$hari;


$sql = "INSERT INTO user VALUES('','$waktu')";
mysqli_query($conn,$sql);

header('location:index.php?sukses');
?>