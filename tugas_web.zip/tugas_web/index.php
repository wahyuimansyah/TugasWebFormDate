<!DOCTYPE HTML>
<html>
<head>
<title>Entry Tanggal</title>
<?php
    if(isset($_GET['sukses'])){
      echo "<span style='color:green;'>data berhasil masuk...</span>";
    }
  ?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body>
  <form action="proses.php" method="POST" enctype="multipart/form-data" name="TANGGAL">
    <table width="452" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#666666">
      <tr>
        <td height="40" align="center" bgcolor="#ffffff"><strong><font color="#000000">FORM INPUT DATA </font></strong></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF"><table width="452" border="0" align="center" cellpadding="5" cellspacing="0">
            
            <tr>
              <td>Tanggal Lahir</td>
              <td>:</td>
              <td><select name="tgl" size="1" id="tgl">
                  <?php
		     for ($tgl=1;$tgl<=31;$tgl++)
			 {
			   echo "<option value=".$tgl.">".$tgl."</option>";
			 }
		  ?>
                </select>
                <select name="bln" size="1" id="bln">
                  <?php
		     $Nbulan=array("","Januari","Pebruari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember");
		     for ($bln=1;$bln<=12;$bln++)
			 {
			   echo "<option value=".$bln.">".$Nbulan[$bln]."</option>";
			 }
		  ?>
                </select>
                <select name="thn" size="1" id="thn">
                  <?php
		     for ($thn=1985;$thn<=2000;$thn++)
			 {
			   echo "<option value=".$thn.">".$thn."</option>";
			 }
		  ?>
              </select></td>
            </tr>
            
            <tr>
              <td colspan="3" align="center"><input name="" type="submit" id="fok" value="OK">
                <input type="reset"  value="Ulangi">
                <input type="button"  value="Kembali" onClick="javascript:history.back()"></td>
            </tr>
        </table></td>
      </tr>
    </table>
  </form>
</body>
</html>
